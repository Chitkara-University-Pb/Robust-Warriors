var count=1;
$( document ).ready(function() {
  
    $("#ni-d-1" ).click(function() {
       
    //   $("#btn1").hide();
      $("#sub1").show();
      $( "#sub1" ).css('background', 'green');
      
      $("#c1").show();
      $("#plus1").show().css('background', 'green');
   
    $("#sub1").click(function(){
      if(count>=2) {
        count=count-1;
        document.getElementById("c1").innerText=count;
        document.getElementById("p1p").innerText="x"+count;
        num3=count;
      }else if (count=1) {
          
          $("#ni-d-1").show();
          $("#sub1").hide();
          $("#c1").hide();
          $("#plus1").hide();
          $("#p1").hide();
          $("#p1p").hide();
        
        
      }
    });
    $("#plus1").click(function(){
        count=count+1;
        document.getElementById("c1").innerText=count;
        document.getElementById("p1p").innerText="x"+count;
        num3=count;
    });
    
     
      
      
      
    });
  });

  //---
  $( document ).ready(function() {
    $("#ni-d-2" ).click(function() {
       
    //   $("#btn1").hide();
      $("#sub2").show();
      $( "#sub2" ).css('background', 'green');
      
      $("#c2").show();
      $("#plus2").show().css('background', 'green');
   
    $("#sub2").click(function(){
      if(count>=2) {
        count=count-1;
        document.getElementById("c2").innerText=count;
        document.getElementById("p2p").innerText="x"+count;
        num3=count;
      }else if (count=1) {
          
          $("#ni-d-2").show();
          $("#sub2").hide();
          $("#c2").hide();
          $("#plus2").hide();
          $("#p2").hide();
          $("#p2p").hide();
        
        
      }
    });
    $("#plus2").click(function(){
        count=count+1;
        document.getElementById("c2").innerText=count;
        document.getElementById("p2p").innerText="x"+count;
        num3=count;
    });
    
     
      
      
      
    });
  });

  //---

$( document ).ready(function() {
    $("#ni-d-3" ).click(function() {
       
    //   $("#btn1").hide();
      $("#sub3").show();
      $( "#sub3" ).css('background', 'green');
      
      $("#c3").show();
      $("#plus3").show().css('background', 'green');
   
    $("#sub3").click(function(){
      if(count>=2) {
        count=count-1;
        document.getElementById("c3").innerText=count;
        document.getElementById("p3p").innerText="x"+count;
        num3=count;
      }else if (count=1) {
          
          $("#ni-d-3").show();
          $("#sub3").hide();
          $("#c3").hide();
          $("#plus3").hide();
          $("#p3").hide();
          $("#p3p").hide();
        
        
      }
    });
    $("#plus3").click(function(){
        count=count+1;
        document.getElementById("c3").innerText=count;
        document.getElementById("p3p").innerText="x"+count;
        num3=count;
    });
    
     
      
      
      
    });
  });
//-

$( document ).ready(function() {
    $("#ni-d-4" ).click(function() {
       
    //   $("#btn1").hide();
      $("#sub4").show();
      $( "#sub4" ).css('background', 'green');
      
      $("#c4").show();
      $("#plus4").show().css('background', 'green');
   
    $("#sub4").click(function(){
      if(count>=2) {
        count=count-1;
        document.getElementById("c4").innerText=count;
        document.getElementById("p4p").innerText="x"+count;
        num3=count;
      }else if (count=1) {
          
          $("#ni-d-4").show();
          $("#sub4").hide();
          $("#c4").hide();
          $("#plus4").hide();
          $("#p4").hide();
          $("#p4p").hide();
        
        
      }
    });
    $("#plus4").click(function(){
        count=count+1;
        document.getElementById("c4").innerText=count;
        document.getElementById("p4p").innerText="x"+count;
        num3=count;
    });
    
     
      
      
      
    });
  });
//-

$( document ).ready(function() {
    $("#ni-d-5" ).click(function() {
       
    //   $("#btn1").hide();
      $("#sub5").show();
      $( "#sub5" ).css('background', 'green');
      
      $("#c5").show();
      $("#plus5").show().css('background', 'green');
   
    $("#sub5").click(function(){
      if(count>=2) {
        count=count-1;
        document.getElementById("c5").innerText=count;
        document.getElementById("p5p").innerText="x"+count;
        num3=count;
      }else if (count=1) {
          
          $("#ni-d-5").show();
          $("#sub5").hide();
          $("#c5").hide();
          $("#plus5").hide();
          $("#p5").hide();
          $("#p5p").hide();
        
        
      }
    })
    $("#plus5").click(function(){
        count=count+1;
        document.getElementById("c5").innerText=count;
        document.getElementById("p5p").innerText="x"+count;
        num3=count;
    });
    
     
      
      
      
    });
  });
//-
$( document ).ready(function() {
    $("#ni-d-6" ).click(function() {
       
    //   $("#btn1").hide();
      $("#sub6").show();
      $( "#sub6" ).css('background', 'green');
      
      $("#c6").show();
      $("#plus6").show().css('background', 'green');
   
    $("#sub6").click(function(){
      if(count>=2) {
        count=count-1;
        document.getElementById("c6").innerText=count;
        document.getElementById("p6p").innerText="x"+count;
        num3=count;
      }else if (count=1) {
          
          $("#ni-d-6").show();
          $("#sub6").hide();
          $("#c6").hide();
          $("#plus6").hide();
          $("#p6").hide();
          $("#p6p").hide();
        
        
      }
    });
    $("#plus6").click(function(){
        count=count+1;
        document.getElementById("c6").innerText=count;
        document.getElementById("p6p").innerText="x"+count;
        num3=count;
    });
    
     
      
      
      
    });
  });
