function func1(){
    window.open('North-Indian.html')
};
function func2(){
    window.open('EasternIndia.html')
};
function func3(){
    window.open('South-Indian.html')
};